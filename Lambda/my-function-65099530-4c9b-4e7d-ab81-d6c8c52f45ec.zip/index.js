// Load the AWS SDK for Node.js
var AWS = require('aws-sdk');
// Set region
AWS.config.update({region: 'us-east-2'});

exports.handler = async (event) => {
     var input = event.body;
     //remove punctuation marks and reformat the string, then store as array
     input = input.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"");
     var bodyWords = input.toLowerCase().split(" ");
     
     var wordCount = new Map();
     for(var i = 0; i < bodyWords.length; i++){
       if(wordCount.has(bodyWords[i]) === false){
         wordCount.set(bodyWords[i], 1);
        } else {
          wordCount.set(bodyWords[i], wordCount.get(bodyWords[i]) + 1);
        }
      }
      var concordance = [];
      for(let [word, count] of wordCount){
        var concordObj = {};
        concordObj.token = word;
        concordObj.count = count;
        concordance.push(concordObj);
      }
      var examples = {};
        examples['application/json'] = {
          "Input" : input,
          "concordance" : concordance
        };
    console.log("input: " + input);
    console.dir("concordance: " + JSON.stringify(concordance));    
    /*    
    console.log("Start building sns message to publish");
        var params = {
            Message: JSON.stringify(examples), 
            Subject: "Test SNS From Lambda",
            TopicArn: "arn:aws:sns:us-east-2:395234341975:Concordance1"
        };
        console.log(params);
        var sns = new AWS.SNS();
        sns.publish(params,  function(err, data) {
          if (err) console.log(err, err.stack); // an error occurred
          else     console.log(data);           // successful response
        });
      */
  
    const response = {
        statusCode: 200,
        body: JSON.stringify(examples)
    };
    return response;
};
